import unittest

from pxb_bench.workload import (
    contiguous_id_batches,
    contiguous_pages,
    id_batches,
    page_step,
    scattered_id_batches,
)


class ScatteredWorkloadTests(unittest.TestCase):
    def test_page_step_matches_original_formula(self):
        self.assertEqual(page_step(5, 73), 73 * 100 // 5)
        self.assertEqual(page_step(100, 73), 73)

    def test_first_batch_has_batch_size_ids(self):
        batches = list(
            scattered_id_batches(5, total_rows=100_000_000, rows_per_page=73, batch_size=1000)
        )
        step = page_step(5, 73)
        self.assertEqual(len(batches[0]), 1000)
        self.assertEqual(batches[0][0], 1)
        self.assertEqual(batches[0][1], 1 + step)
        self.assertEqual(batches[0][-1], 1 + 999 * step)

    def test_ids_never_exceed_total_rows(self):
        total = 10_000
        for batch in scattered_id_batches(100, total_rows=total, rows_per_page=73, batch_size=1000):
            self.assertTrue(batch)
            self.assertTrue(all(1 <= n <= total for n in batch))


class ContiguousWorkloadTests(unittest.TestCase):
    def test_page_count_is_leading_percent(self):
        # 1000 rows / 10 per page = 100 pages; 10% -> first 10 pages
        self.assertEqual(contiguous_pages(10, total_rows=1000, rows_per_page=10), 10)

    def test_ids_are_first_pages_in_order(self):
        batches = list(
            contiguous_id_batches(10, total_rows=1000, rows_per_page=10, batch_size=1000)
        )
        self.assertEqual(len(batches), 1)
        self.assertEqual(batches[0], [1, 11, 21, 31, 41, 51, 61, 71, 81, 91])

    def test_batches_split(self):
        batches = list(
            contiguous_id_batches(10, total_rows=1000, rows_per_page=10, batch_size=4)
        )
        self.assertEqual(batches[0], [1, 11, 21, 31])
        self.assertEqual(batches[-1], [81, 91])

    def test_dispatcher(self):
        scattered = list(id_batches("scattered", 10, 1000, 10, 1000))
        contiguous = list(id_batches("contiguous", 10, 1000, 10, 1000))
        self.assertNotEqual(scattered[0][:10], contiguous[0][:10])
        self.assertEqual(contiguous[0][1] - contiguous[0][0], 10)
