import unittest
from pathlib import Path

from pxb_bench.parse import stream_times, table_stream_seconds

FIXTURE = Path(__file__).parent / "fixtures" / "inc.log"


class ParseTests(unittest.TestCase):
    def test_stream_times_sorted_longest_first(self):
        results = stream_times(FIXTURE)
        self.assertEqual(results[0], (4.25, "./test/sbtest1.ibd"))
        self.assertEqual(results[1], (1.0, "./mysql/ibdata1.ibd"))

    def test_table_stream_seconds(self):
        self.assertEqual(table_stream_seconds(FIXTURE, "./test/sbtest1.ibd"), 4.25)
        self.assertIsNone(table_stream_seconds(FIXTURE, "./missing.ibd"))
