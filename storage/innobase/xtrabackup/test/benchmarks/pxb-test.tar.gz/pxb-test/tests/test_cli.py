import unittest

from pxb_bench.cli import build_parser


class CliTests(unittest.TestCase):
    def test_percent_range(self):
        args = build_parser().parse_args(["run", "--percents", "5:20:5"])
        self.assertEqual(args.percents, [5, 10, 15, 20])

    def test_gaps(self):
        args = build_parser().parse_args(["inc-backup", "15", "auto"])
        self.assertEqual(args.percent, 15)
        self.assertEqual(args.gap, "auto")
        self.assertEqual(args.workload, "scattered")

    def test_workloads(self):
        args = build_parser().parse_args(["run", "--workloads", "contiguous"])
        self.assertEqual(args.workloads, ["contiguous"])

    def test_change_data_contiguous(self):
        args = build_parser().parse_args(["change-data", "10", "--workload", "contiguous"])
        self.assertEqual(args.percent, 10)
        self.assertEqual(args.workload, "contiguous")
