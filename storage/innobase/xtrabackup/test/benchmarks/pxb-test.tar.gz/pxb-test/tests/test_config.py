import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from pxb_bench.config import find_config, find_workdir, load_config, load_toml, looks_like_sandbox

REPO_CONFIG = Path(__file__).resolve().parents[1] / "config.toml"


class ConfigTests(unittest.TestCase):
    def test_load_repo_toml(self):
        raw = load_toml(REPO_CONFIG)
        self.assertEqual(raw["sandbox"]["port"], 8408)
        self.assertEqual(raw["experiment"]["workloads"], ["scattered", "contiguous"])
        self.assertIn(5, raw["experiment"]["percents"])
        self.assertEqual(raw["experiment"]["gaps"][1], "0")

    def test_find_workdir_uses_parent_sandbox(self):
        with tempfile.TemporaryDirectory() as raw:
            sandbox = Path(raw)
            (sandbox / "use").write_text("")
            (sandbox / "my.sandbox.cnf").write_text("")
            project = sandbox / "pxb-test"
            project.mkdir()
            self.assertTrue(looks_like_sandbox(sandbox))
            with patch("pxb_bench.config.package_root", return_value=project):
                with patch("pxb_bench.config.Path.cwd", return_value=project):
                    self.assertEqual(find_workdir(None), sandbox.resolve())

    def test_find_config_falls_back_to_project_tree(self):
        found = find_config(Path("config.toml"), Path("/tmp/does-not-exist"))
        self.assertEqual(found, REPO_CONFIG.resolve())

    def test_load_config_resolves_relative_paths(self):
        cfg = load_config(REPO_CONFIG, Path("/tmp/sandbox"))
        self.assertEqual(cfg.sandbox.port, 8408)
        self.assertEqual(cfg.experiment.workloads, ["scattered", "contiguous"])
        self.assertEqual(cfg.sandbox.use, Path("/tmp/sandbox/use").resolve())
