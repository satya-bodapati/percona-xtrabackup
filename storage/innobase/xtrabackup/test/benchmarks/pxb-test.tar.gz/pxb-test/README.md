# pxb-bench

Measure how long Percona XtraBackup takes to stream `test.sbtest1` in an
incremental backup, as more InnoDB pages are dirtied and as page-tracking gap
modes change (`none`, `0`, `auto`).

## Experiment

For each workload:

1. Take one page-tracked full backup (`--history=sbtest`).
2. For each dirty-page percent (default 5, 10, …, 100), dirty that many pages
   and run an incremental from history `sbtest` for each gap mode.
   - **scattered**: one dirty page every N pages across the table.
   - **contiguous**: dirty page 1, 2, 3, … for the first N% of pages.
3. Record the `sbtest1.ibd` stream time from the xtrabackup log.

There is no full backup or mysqld restart between percents. Later percents add
more dirty pages on top of earlier ones (since the same full backup). Use
`pxb-bench restart` yourself if you want a flush.

`none` omits `--page-tracking`. `0` and `auto` pass `--page-tracking-merge-gap`.

## Layout

```
config.toml          # sandbox, xtrabackup, workload, experiment
pxb_bench/           # CLI and library
  cli.py
  experiment.py      # the percent × gap loop
  backup.py          # full and incremental xtrabackup
  workload.py        # page-dirtying ID batches
  parse.py           # stream-time extraction
  sandbox.py         # ./use and ./restart
tests/
```

## Setup

Python 3.9+. Edit `config.toml` so binaries, port, and sandbox paths match the
host. Relative paths are resolved against `--workdir` (the MySQL sandbox).

```bash
python3 -m pip install -e .
```

The sandbox must already have `test.sbtest1` with `total_rows` rows (default
100 million). `rows_per_page` (default 73) is the estimated rows per 16KiB page
for this schema; it only affects how many pages get dirtied.

## Run

`config.toml` is loaded from the current directory, `--workdir`, or the
project checkout (so you can run from the MySQL sandbox). Override with
`--config /path/to/config.toml`.

`--workdir` defaults to the current directory, or the parent sandbox when
this repo lives inside one (for example `msb_8_4_8/pxb-test`).

From the sandbox directory, or pass `--workdir`:

```bash
# same loop as the original scripts
pxb-bench --workdir /path/to/sandbox run

# smaller sweep
pxb-bench run --percents 5:25:5 --gaps none,0,auto --workloads contiguous

# individual steps
pxb-bench full-backup
pxb-bench change-data 15 --workload contiguous
pxb-bench restart
pxb-bench inc-backup 15 auto --workload contiguous
pxb-bench parse-log logs/contiguous_15_gap_auto.log
```

Results go to `results/latest.csv` and a timestamped `results/run_*.csv`.
Incremental logs stay in `logs/<workload>_<percent>_gap_<gap>.log`.

```bash
PYTHONPATH=. python3 -m unittest discover -s tests
```
