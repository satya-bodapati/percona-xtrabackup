from __future__ import annotations

import csv
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from pxb_bench.backup import full_backup, incremental_backup
from pxb_bench.config import Config
from pxb_bench.sandbox import ensure_dirs, restart_after_slow_shutdown
from pxb_bench.workload import dirty_pages

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class RunResult:
    workload: str
    percent: int
    gap: str
    seconds: float | None


def run_experiment(
    cfg: Config,
    percents: list[int] | None = None,
    gaps: list[str] | None = None,
    workloads: list[str] | None = None,
) -> list[RunResult]:
    percents = percents or cfg.experiment.percents
    gaps = gaps or cfg.experiment.gaps
    workloads = workloads or cfg.experiment.workloads
    ensure_dirs(cfg.experiment.logs_dir, cfg.experiment.results_dir)

    results: list[RunResult] = []
    for workload in workloads:
        log.info("=== %s: full backup (once) ===", workload)
        full_backup(cfg)
        for percent in percents:
            log.info("=== %s  %s%% dirtied pages ===", workload, percent)
            dirty_pages(cfg, percent, workload)
            # a clean restart (innodb_fast_shutdown=0) flushes every
            # dirtied page, so the tracked changed-page set is complete
            # and identical for all gap modes of this density regardless
            # of the table-to-buffer-pool ratio; it also starts every
            # density buffer-pool-cold
            restart_after_slow_shutdown(cfg)
            for gap in gaps:
                seconds = incremental_backup(cfg, workload, percent, gap)
                results.append(RunResult(workload, percent, gap, seconds))

    path = write_results(cfg.experiment.results_dir, results)
    log.info("wrote %s", path)
    _print_table(results)
    return results


def write_results(results_dir: Path, results: list[RunResult]) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    path = results_dir / f"run_{stamp}.csv"
    latest = results_dir / "latest.csv"
    fieldnames = ["workload", "percent", "gap", "sbtest1_seconds"]
    rows = [
        {
            "workload": row.workload,
            "percent": row.percent,
            "gap": row.gap,
            "sbtest1_seconds": "" if row.seconds is None else f"{row.seconds:.3f}",
        }
        for row in results
    ]
    for dest in (path, latest):
        with dest.open("w", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)
    return path


def _print_table(results: list[RunResult]) -> None:
    print(f"{'workload':<12}  {'percent':>8}  {'gap':<6}  {'sbtest1_s':>10}")
    for row in results:
        value = "-" if row.seconds is None else f"{row.seconds:.3f}"
        print(f"{row.workload:<12}  {row.percent:8d}  {row.gap:<6}  {value:>10}")
