from __future__ import annotations

import logging
import subprocess
from pathlib import Path

from pxb_bench.config import Config

log = logging.getLogger(__name__)


def mysql(cfg: Config, sql: str) -> str:
    cmd = [str(cfg.sandbox.use), "-BNe", sql]
    result = subprocess.run(
        cmd,
        cwd=cfg.workdir,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.stderr:
        log.debug("%s", result.stderr.strip())
    return result.stdout


def restart_after_slow_shutdown(cfg: Config) -> None:
    log.info("flushing dirty pages (innodb_fast_shutdown=0) and restarting")
    mysql(cfg, "SET GLOBAL innodb_fast_shutdown = 0")
    subprocess.run(
        [str(cfg.sandbox.restart)],
        cwd=cfg.workdir,
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def ensure_dirs(*paths: Path) -> None:
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
