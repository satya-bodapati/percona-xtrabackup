from __future__ import annotations

import logging
from collections.abc import Iterator

from pxb_bench.config import WORKLOADS, Config
from pxb_bench.sandbox import mysql

log = logging.getLogger(__name__)


def page_step(percent: int, rows_per_page: int) -> int:
    """ID stride that dirties about `percent` of pages (one row per page)."""
    if not 1 <= percent <= 100:
        raise ValueError(f"percent must be 1..100, got {percent}")
    return max(1, rows_per_page * 100 // percent)


def page_count(total_rows: int, rows_per_page: int) -> int:
    return max(1, (total_rows + rows_per_page - 1) // rows_per_page)


def contiguous_pages(percent: int, total_rows: int, rows_per_page: int) -> int:
    """How many leading pages to dirty for a contiguous `percent` workload."""
    if not 1 <= percent <= 100:
        raise ValueError(f"percent must be 1..100, got {percent}")
    return max(1, page_count(total_rows, rows_per_page) * percent // 100)


def scattered_id_batches(
    percent: int,
    total_rows: int,
    rows_per_page: int,
    batch_size: int,
) -> Iterator[list[int]]:
    """One row every `page_step` IDs, spread across the table."""
    step = page_step(percent, rows_per_page)
    stride = batch_size * step
    for offset in range(0, total_rows, stride):
        last = offset + (batch_size - 1) * step + 1
        ids = [n for n in range(offset + 1, last + 1, step) if n <= total_rows]
        if not ids:
            break
        yield ids


def contiguous_id_batches(
    percent: int,
    total_rows: int,
    rows_per_page: int,
    batch_size: int,
) -> Iterator[list[int]]:
    """One row on page 1, 2, 3, … for the first `percent` of pages."""
    pages = contiguous_pages(percent, total_rows, rows_per_page)
    for start in range(0, pages, batch_size):
        ids = []
        for page in range(start, min(start + batch_size, pages)):
            row_id = 1 + page * rows_per_page
            if row_id <= total_rows:
                ids.append(row_id)
        if ids:
            yield ids


def id_batches(
    workload: str,
    percent: int,
    total_rows: int,
    rows_per_page: int,
    batch_size: int,
) -> Iterator[list[int]]:
    if workload == "scattered":
        yield from scattered_id_batches(percent, total_rows, rows_per_page, batch_size)
    elif workload == "contiguous":
        yield from contiguous_id_batches(percent, total_rows, rows_per_page, batch_size)
    else:
        raise ValueError(f"unknown workload {workload!r}; choose from {WORKLOADS}")


def dirty_pages(cfg: Config, percent: int, workload: str) -> None:
    """Dirty ~percent of sbtest pages with DELETE + ROLLBACK (no committed change)."""
    wl = cfg.workload
    table = f"{cfg.sandbox.schema}.{cfg.sandbox.table}"
    batches = list(id_batches(workload, percent, wl.total_rows, wl.rows_per_page, wl.batch_size))
    if workload == "contiguous":
        log.info(
            "dirtying first ~%s%% of pages contiguously (%s batches, %s pages)",
            percent,
            len(batches),
            contiguous_pages(percent, wl.total_rows, wl.rows_per_page),
        )
    else:
        log.info(
            "dirtying ~%s%% of pages scattered (%s batches, step=%s)",
            percent,
            len(batches),
            page_step(percent, wl.rows_per_page),
        )
    for i, ids in enumerate(batches, start=1):
        id_list = ",".join(str(n) for n in ids)
        mysql(cfg, f"BEGIN; DELETE FROM {table} WHERE id IN ({id_list}); ROLLBACK;")
        if i == 1 or i % 50 == 0 or i == len(batches):
            log.debug("dirty-page batch %s/%s", i, len(batches))
