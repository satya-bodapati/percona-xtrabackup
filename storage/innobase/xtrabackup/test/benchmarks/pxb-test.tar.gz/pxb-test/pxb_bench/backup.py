from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

from pxb_bench.config import Config
from pxb_bench.parse import table_stream_seconds
from pxb_bench.sandbox import ensure_dirs

log = logging.getLogger(__name__)


class BackupError(RuntimeError):
    pass


def _run_xtrabackup(
    cmd: list[str],
    cwd: Path,
    log_path: Path,
    stdout: object,
) -> None:
    binary = Path(cmd[0])
    if not binary.is_file():
        raise BackupError(f"xtrabackup not found: {binary}")
    log.debug("%s", " ".join(cmd))
    with log_path.open("w") as err_fh:
        result = subprocess.run(cmd, cwd=cwd, stdout=stdout, stderr=err_fh)
    if result.returncode != 0:
        tail = log_path.read_text(errors="replace")[-4000:]
        raise BackupError(
            f"xtrabackup exited {result.returncode}\nlog: {log_path}\n{tail}"
        )


def _connection_args(cfg: Config) -> list[str]:
    sandbox = cfg.sandbox
    return [
        f"--user={sandbox.user}",
        f"--password={sandbox.password}",
        f"--host={sandbox.host}",
        f"--port={sandbox.port}",
    ]


def full_backup(cfg: Config) -> None:
    target = cfg.xtrabackup.full_target_dir
    if target.exists():
        shutil.rmtree(target)
    ensure_dirs(target, cfg.experiment.logs_dir)

    cmd = [
        str(cfg.xtrabackup.full_binary),
        f"--defaults-file={cfg.sandbox.defaults_file}",
        "--backup",
        f"--target-dir={target}",
        f"--history={cfg.xtrabackup.history_name}",
        "--page-tracking",
        f"--compress={cfg.xtrabackup.compress}",
        f"--compress-threads={cfg.xtrabackup.compress_threads}",
        *_connection_args(cfg),
    ]
    log_path = cfg.experiment.logs_dir / "full.log"
    log.debug("full backup -> %s", target)
    _run_xtrabackup(cmd, cfg.workdir, log_path, subprocess.DEVNULL)


def incremental_log_path(cfg: Config, workload: str, percent: int, gap: str) -> Path:
    return cfg.experiment.logs_dir / f"{workload}_{percent}_gap_{gap}.log"


def incremental_backup(cfg: Config, workload: str, percent: int, gap: str) -> float | None:
    stream = cfg.xtrabackup.incremental_stream
    ensure_dirs(stream.parent, cfg.experiment.logs_dir)

    cmd = [
        str(cfg.xtrabackup.incremental_binary),
        f"--defaults-file={cfg.sandbox.defaults_file}",
        "--backup",
        "--stream=xbstream",
        f"--parallel={cfg.xtrabackup.parallel}",
        f"--incremental-history-name={cfg.xtrabackup.history_name}",
        f"--extra-lsndir={cfg.xtrabackup.extra_lsn_dir}",
        *_connection_args(cfg),
    ]
    if gap != "none":
        cmd.extend(["--page-tracking", f"--page-tracking-combine-distance={gap}"])

    log_path = incremental_log_path(cfg, workload, percent, gap)
    log.debug(
        "incremental backup workload=%s gap=%s percent=%s -> %s",
        workload,
        gap,
        percent,
        stream,
    )
    with stream.open("wb") as stdout:
        _run_xtrabackup(cmd, cfg.workdir, log_path, stdout)

    relpath = f"./{cfg.sandbox.schema}/{cfg.sandbox.table}.ibd"
    seconds = table_stream_seconds(log_path, relpath)
    if seconds is None:
        log.warning("no stream time for %s in %s", relpath, log_path)
    else:
        log.info("%10.3f  %s", seconds, relpath)
    return seconds
