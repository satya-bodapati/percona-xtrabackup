from __future__ import annotations

import csv
import os
import time
import re

import logging
import shutil
import subprocess
from pathlib import Path

from pxb_bench.config import Config
from pxb_bench.parse import table_stream_seconds
from pxb_bench.sandbox import ensure_dirs

log = logging.getLogger(__name__)


class BackupError(RuntimeError):
    pass


def _run_xtrabackup(
    cmd: list[str],
    cwd: Path,
    log_path: Path,
    stdout: object,
) -> None:
    binary = Path(cmd[0])
    if not binary.is_file():
        raise BackupError(f"xtrabackup not found: {binary}")
    log.debug("%s", " ".join(cmd))
    with log_path.open("w") as err_fh:
        result = subprocess.run(cmd, cwd=cwd, stdout=stdout, stderr=err_fh)
    if result.returncode != 0:
        tail = log_path.read_text(errors="replace")[-4000:]
        raise BackupError(
            f"xtrabackup exited {result.returncode}\nlog: {log_path}\n{tail}"
        )


def _connection_args(cfg: Config) -> list[str]:
    sandbox = cfg.sandbox
    return [
        f"--user={sandbox.user}",
        f"--password={sandbox.password}",
        f"--host={sandbox.host}",
        f"--port={sandbox.port}",
    ]


def full_backup(cfg: Config) -> None:
    target = cfg.xtrabackup.full_target_dir
    if target.exists():
        shutil.rmtree(target)
    ensure_dirs(target, cfg.experiment.logs_dir)

    cmd = [
        str(cfg.xtrabackup.full_binary),
        f"--defaults-file={cfg.sandbox.defaults_file}",
        "--backup",
        f"--target-dir={target}",
        f"--history={cfg.xtrabackup.history_name}",
        "--page-tracking",
        f"--compress={cfg.xtrabackup.compress}",
        f"--compress-threads={cfg.xtrabackup.compress_threads}",
        *_connection_args(cfg),
    ]
    log_path = cfg.experiment.logs_dir / "full.log"
    log.debug("full backup -> %s", target)
    _run_xtrabackup(cmd, cfg.workdir, log_path, subprocess.DEVNULL)


def incremental_log_path(cfg: Config, workload: str, percent: int, gap: str) -> Path:
    return cfg.experiment.logs_dir / f"{workload}_{percent}_gap_{gap}.log"


def _drop_table_cache(cfg: Config) -> None:
    """Evict the benchmark table from the OS page cache so every cell
    measures storage, not RAM warmed by the previous cell. Drops clean
    pages only; the running server is unaffected beyond colder reads.
    A no-op on O_DIRECT servers and where posix_fadvise is missing."""
    path = cfg.workdir / "data" / cfg.sandbox.schema / f"{cfg.sandbox.table}.ibd"
    try:
        os.sync()
        fd = os.open(path, os.O_RDONLY)
        try:
            os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
        finally:
            os.close(fd)
    except (OSError, AttributeError):
        pass


def _diskstats(cfg: Config) -> dict | None:
    """Snapshot /proc/diskstats for the whole device holding the datadir
    (partition suffix stripped), so per-cell read bandwidth, latency,
    queue depth and utilisation can be derived from two snapshots."""
    try:
        src = subprocess.run(
            ["df", "--output=source", str(cfg.workdir / "data")],
            capture_output=True, text=True, check=True,
        ).stdout.splitlines()[-1].strip()
        dev = re.sub(r"^/dev/", "", src)
        m = re.match(r"(nvme\d+n\d+)p\d+$", dev) or re.match(r"([a-z]+)\d+$", dev)
        if m:
            dev = m.group(1)
        for line in open("/proc/diskstats"):
            f = line.split()
            if len(f) > 13 and f[2] == dev:
                return {"dev": dev, "t": time.monotonic(), "r_ios": int(f[3]),
                        "r_sectors": int(f[5]), "r_ticks": int(f[6]),
                        "io_ticks": int(f[12]), "weighted": int(f[13])}
    except (OSError, subprocess.SubprocessError, ValueError, IndexError):
        pass
    return None


def _write_diskstats(cfg: Config, workload: str, percent: int, gap: str,
                     before: dict | None, after: dict | None) -> None:
    """Append one row of per-cell disk telemetry to results/diskstats.csv."""
    if not before or not after:
        return
    elapsed = max(after["t"] - before["t"], 1e-6)
    r_ios = after["r_ios"] - before["r_ios"]
    read_mb = (after["r_sectors"] - before["r_sectors"]) * 512 / 1048576
    r_ticks = after["r_ticks"] - before["r_ticks"]
    row = {
        "workload": workload, "percent": percent, "gap": gap,
        "dev": after["dev"], "elapsed_s": f"{elapsed:.1f}",
        "read_MB": f"{read_mb:.0f}", "read_MBps": f"{read_mb / elapsed:.1f}",
        "read_iops": f"{r_ios / elapsed:.0f}",
        "r_await_ms": f"{r_ticks / r_ios:.3f}" if r_ios else "",
        "avg_qd": f"{(after['weighted'] - before['weighted']) / elapsed / 1000:.2f}",
        "util_pct": f"{(after['io_ticks'] - before['io_ticks']) / elapsed / 10:.1f}",
    }
    path = cfg.experiment.results_dir / "diskstats.csv"
    new = not path.exists()
    with path.open("a", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(row))
        if new:
            w.writeheader()
        w.writerow(row)


def incremental_backup(cfg: Config, workload: str, percent: int, gap: str) -> float | None:
    _drop_table_cache(cfg)
    stream = cfg.xtrabackup.incremental_stream
    ensure_dirs(stream.parent, cfg.experiment.logs_dir)

    cmd = [
        str(cfg.xtrabackup.incremental_binary),
        f"--defaults-file={cfg.sandbox.defaults_file}",
        "--backup",
        "--stream=xbstream",
        f"--parallel={cfg.xtrabackup.parallel}",
        f"--incremental-history-name={cfg.xtrabackup.history_name}",
        f"--extra-lsndir={cfg.xtrabackup.extra_lsn_dir}",
        *_connection_args(cfg),
    ]
    if gap != "none":
        cmd.extend(["--page-tracking", f"--page-tracking-merge-gap={gap}"])

    log_path = incremental_log_path(cfg, workload, percent, gap)
    log.debug(
        "incremental backup workload=%s gap=%s percent=%s -> %s",
        workload,
        gap,
        percent,
        stream,
    )
    disk_before = _diskstats(cfg)
    with stream.open("wb") as stdout:
        _run_xtrabackup(cmd, cfg.workdir, log_path, stdout)
    _write_diskstats(cfg, workload, percent, gap, disk_before, _diskstats(cfg))

    relpath = f"./{cfg.sandbox.schema}/{cfg.sandbox.table}.ibd"
    seconds = table_stream_seconds(log_path, relpath)
    if seconds is None:
        log.warning("no stream time for %s in %s", relpath, log_path)
    else:
        log.info("%10.3f  %s", seconds, relpath)
    return seconds
