"""Benchmark Percona XtraBackup incremental backups."""

__version__ = "0.1.0"
