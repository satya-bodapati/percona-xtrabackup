from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from pxb_bench.backup import BackupError, full_backup, incremental_backup
from pxb_bench.config import WORKLOADS, find_config, find_workdir, load_config
from pxb_bench.experiment import run_experiment
from pxb_bench.parse import table_stream_seconds
from pxb_bench.sandbox import restart_after_slow_shutdown
from pxb_bench.workload import dirty_pages


def _parse_int_list(value: str) -> list[int]:
    if ":" in value:
        parts = value.split(":")
        if len(parts) != 3:
            raise argparse.ArgumentTypeError("use start:stop:step, e.g. 5:100:5")
        start, stop, step = (int(p) for p in parts)
        return list(range(start, stop + 1, step))
    return [int(item) for item in value.split(",") if item]


def _gap_mode(value: str) -> str:
    """none, auto, or a page count for --page-tracking-merge-gap."""
    if value in ("none", "auto") or value.isdigit():
        return value
    raise argparse.ArgumentTypeError(
        f"{value!r}: expected none, auto, or a page count"
    )


def _parse_gaps(value: str) -> list[str]:
    return [item for item in value.split(",") if item]


def _parse_workloads(value: str) -> list[str]:
    names = [item for item in value.split(",") if item]
    unknown = [name for name in names if name not in WORKLOADS]
    if unknown:
        raise argparse.ArgumentTypeError(
            f"unknown workload(s) {unknown}; choose from {','.join(WORKLOADS)}"
        )
    return names


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pxb-bench",
        description="Benchmark Percona XtraBackup incremental backups.",
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("config.toml"),
        help="TOML config (default: config.toml in cwd, workdir, or the project tree)",
    )
    parser.add_argument(
        "--workdir",
        type=Path,
        default=None,
        help="MySQL sandbox directory (default: cwd, or the sandbox that contains this repo)",
    )
    parser.add_argument("-v", "--verbose", action="store_true")

    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="full experiment: backup, dirty pages, incrementals")
    run.add_argument("--percents", type=_parse_int_list, help="e.g. 5:100:5 or 5,10,25")
    run.add_argument("--gaps", type=_parse_gaps, help="comma-separated, e.g. none,0,auto")
    run.add_argument(
        "--workloads",
        type=_parse_workloads,
        help="comma-separated, e.g. scattered,contiguous",
    )

    sub.add_parser("full-backup", help="take a page-tracked full backup")

    change = sub.add_parser("change-data", help="dirty ~N%% of pages (DELETE + ROLLBACK)")
    change.add_argument("percent", type=int)
    change.add_argument(
        "--workload",
        choices=WORKLOADS,
        default="scattered",
        help="scattered (default) or contiguous leading pages",
    )

    inc = sub.add_parser("inc-backup", help="incremental backup for one gap mode")
    inc.add_argument("percent", type=int, help="label used in the log file name")
    inc.add_argument("gap", type=_gap_mode)
    inc.add_argument("--workload", choices=WORKLOADS, default="scattered")

    sub.add_parser("restart", help="innodb_fast_shutdown=0 then restart mysqld")

    parse = sub.add_parser("parse-log", help="print sbtest1.ibd stream time from a log")
    parse.add_argument("log_file", type=Path)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        datefmt="%H:%M:%S",
    )

    if args.command == "parse-log":
        seconds = table_stream_seconds(args.log_file, "./test/sbtest1.ibd")
        if seconds is None:
            print(f"no sbtest1.ibd stream time in {args.log_file}", file=sys.stderr)
            return 1
        print(f"{seconds:10.3f}  ./test/sbtest1.ibd")
        return 0

    workdir = find_workdir(args.workdir)
    try:
        config_path = find_config(args.config, workdir)
    except FileNotFoundError as exc:
        print(exc, file=sys.stderr)
        return 1
    cfg = load_config(config_path, workdir)
    logging.info("workdir %s", cfg.workdir)
    logging.info("config %s", config_path)

    try:
        if args.command == "run":
            run_experiment(
                cfg,
                percents=args.percents,
                gaps=args.gaps,
                workloads=args.workloads,
            )
        elif args.command == "full-backup":
            full_backup(cfg)
        elif args.command == "change-data":
            dirty_pages(cfg, args.percent, args.workload)
        elif args.command == "inc-backup":
            incremental_backup(cfg, args.workload, args.percent, args.gap)
        elif args.command == "restart":
            restart_after_slow_shutdown(cfg)
        else:
            raise AssertionError(args.command)
    except BackupError as exc:
        print(exc, file=sys.stderr)
        return 1
    return 0
