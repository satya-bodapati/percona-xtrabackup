from __future__ import annotations

from datetime import datetime
from pathlib import Path


def stream_times(log_path: Path) -> list[tuple[float, str]]:
    """Elapsed seconds per .ibd streamed in an xtrabackup log."""
    starts: dict[str, datetime] = {}
    results: list[tuple[float, str]] = []

    with log_path.open(errors="ignore") as fh:
        for line in fh:
            if ".ibd" not in line:
                continue

            timestamp = line.split()[0]
            idx = line.find("./")
            if idx == -1:
                continue

            path = line[idx:].strip()

            if "Done: Streaming " in line:
                end = datetime.fromisoformat(timestamp)
                started = starts.pop(path, None)
                if started is not None:
                    results.append(((end - started).total_seconds(), path))
            elif "Streaming" in line:
                starts[path] = datetime.fromisoformat(timestamp)

    results.sort(reverse=True)
    return results


def table_stream_seconds(log_path: Path, relpath: str) -> float | None:
    for elapsed, path in stream_times(log_path):
        if path == relpath:
            return elapsed
    return None
