from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class SandboxConfig:
    defaults_file: Path
    use: Path
    restart: Path
    user: str
    password: str
    host: str
    port: int
    schema: str
    table: str


@dataclass(frozen=True)
class XtraBackupConfig:
    full_binary: Path
    incremental_binary: Path
    history_name: str
    full_target_dir: Path
    incremental_stream: Path
    extra_lsn_dir: Path
    compress: str
    compress_threads: int
    parallel: int


@dataclass(frozen=True)
class WorkloadConfig:
    total_rows: int
    rows_per_page: int
    batch_size: int


WORKLOADS = ("scattered", "contiguous")


@dataclass(frozen=True)
class ExperimentConfig:
    percents: list[int]
    gaps: list[str]
    workloads: list[str]
    logs_dir: Path
    results_dir: Path


@dataclass(frozen=True)
class Config:
    workdir: Path
    sandbox: SandboxConfig
    xtrabackup: XtraBackupConfig
    workload: WorkloadConfig
    experiment: ExperimentConfig


def _workloads(values: list[str]) -> list[str]:
    workloads = [str(item) for item in values]
    unknown = [name for name in workloads if name not in WORKLOADS]
    if unknown:
        raise ValueError(f"unknown workload(s) {unknown}; choose from {WORKLOADS}")
    if not workloads:
        raise ValueError("experiment.workloads must not be empty")
    return workloads


def _resolve(workdir: Path, value: str) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return (workdir / path).resolve()


def package_root() -> Path:
    """Directory that contains pxb_bench/ and (in a git checkout) config.toml."""
    return Path(__file__).resolve().parent.parent


def looks_like_sandbox(path: Path) -> bool:
    return (path / "use").exists() and (path / "my.sandbox.cnf").exists()


def find_workdir(explicit: Path | None) -> Path:
    """Prefer cwd, then the sandbox that contains this project (…/msb/pxb-test)."""
    if explicit is not None:
        return explicit.expanduser().resolve()
    for candidate in (Path.cwd(), package_root().parent, package_root()):
        if looks_like_sandbox(candidate):
            return candidate.resolve()
    return Path.cwd().resolve()


def find_config(path: Path, workdir: Path) -> Path:
    """Resolve config.toml from cwd, workdir, or the project checkout."""
    path = path.expanduser()
    if path.is_absolute():
        candidates = [path]
    else:
        candidates = [Path.cwd() / path, workdir / path, package_root() / path]
    seen: set[Path] = set()
    unique: list[Path] = []
    for candidate in candidates:
        resolved = candidate.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(resolved)
        if resolved.is_file():
            return resolved
    searched = "\n  ".join(str(item) for item in unique)
    raise FileNotFoundError(
        f"{path.name} not found. Looked in:\n  {searched}\n"
        "Pass --config /path/to/config.toml"
    )


def load_toml(path: Path) -> dict:
    """Parse the small TOML subset used by config.toml (stdlib only, Python 3.9+)."""
    data: dict[str, dict] = {}
    section: str | None = None
    for lineno, raw_line in enumerate(path.read_text().splitlines(), start=1):
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            data[section] = {}
            continue
        if section is None or "=" not in line:
            raise ValueError(f"{path}:{lineno}: invalid line: {raw_line}")
        key, value = line.split("=", 1)
        data[section][key.strip()] = ast.literal_eval(value.strip())
    return data


def load_config(path: Path, workdir: Path) -> Config:
    workdir = workdir.resolve()
    raw = load_toml(path)

    sandbox = raw["sandbox"]
    xbk = raw["xtrabackup"]
    workload = raw["workload"]
    experiment = raw["experiment"]

    return Config(
        workdir=workdir,
        sandbox=SandboxConfig(
            defaults_file=_resolve(workdir, sandbox["defaults_file"]),
            use=_resolve(workdir, sandbox["use"]),
            restart=_resolve(workdir, sandbox["restart"]),
            user=sandbox["user"],
            password=sandbox["password"],
            host=sandbox["host"],
            port=int(sandbox["port"]),
            schema=sandbox["schema"],
            table=sandbox["table"],
        ),
        xtrabackup=XtraBackupConfig(
            full_binary=_resolve(workdir, xbk["full_binary"]),
            incremental_binary=_resolve(workdir, xbk["incremental_binary"]),
            history_name=xbk["history_name"],
            full_target_dir=_resolve(workdir, xbk["full_target_dir"]),
            incremental_stream=_resolve(workdir, xbk["incremental_stream"]),
            extra_lsn_dir=_resolve(workdir, xbk["extra_lsn_dir"]),
            compress=xbk["compress"],
            compress_threads=int(xbk["compress_threads"]),
            parallel=int(xbk["parallel"]),
        ),
        workload=WorkloadConfig(
            total_rows=int(workload["total_rows"]),
            rows_per_page=int(workload["rows_per_page"]),
            batch_size=int(workload["batch_size"]),
        ),
        experiment=ExperimentConfig(
            percents=[int(p) for p in experiment["percents"]],
            gaps=[str(g) for g in experiment["gaps"]],
            workloads=_workloads(experiment.get("workloads", list(WORKLOADS))),
            logs_dir=_resolve(workdir, experiment["logs_dir"]),
            results_dir=_resolve(workdir, experiment["results_dir"]),
        ),
    )
